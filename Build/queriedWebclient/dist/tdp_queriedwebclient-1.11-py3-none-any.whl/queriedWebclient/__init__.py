__version__ = "1.11"

from pathlib import Path
ToxFile = Path( Path( __file__ ).parent, "queriedWebclient.tox" )


from ._Typing import Typing